/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package football.project;

/**
 *
 * @author Keegans Laptop
 */
public class LinkedList {
    
    FileOut fout = new FileOut("output.txt");
    
    private Node first;
    private Node last;
    private int i = 0;
    private int j = 0;
    public int y = 0;
    public int z = 0;
    
    Node cow;
    Node stun;
    int cowNum = 0;
    int stunNum = 0;
    
    public void add(int num){
        Node temp = new Node(num);
        if(first == null)
        {
            first = temp;
            last = temp;
            first.setNext(last);
            first.setPrev(last);
            i++;
            cow = last;
            stun = last;
        } 
        else{
            temp.setNext(first);
            temp.setPrev(last);
            first.setPrev(temp);
            first = temp;
            last.setNext(first);
            i++;
            cow = last;
            stun = last;
         }
//        System.out.println(cow.getPrev().getData());
    }
    
    public boolean deleteNode(int num){
        Node iter = first;
//        i--;
        
        while(i != j)
        {
//            System.out.println("check");
            System.out.println(iter.getData());
            
            if (iter == first && iter.getData() == num) {
                first = first.getNext();
                first.setPrev(last);
                return true;
            }
            else if (iter == last && iter.getData() == num) {
                last = last.getPrev();
                last.setNext(first);
                return true;
            }
            else if (iter.getData() == num){
                iter = iter.getNext();
                iter.setPrev(iter.getPrev());
                i--;
                System.out.println("Deleted " + num);
//                printBackwards();
//                print();
                return true;
            }
            iter = iter.getNext();   
            j++;
        }
        j = 0;
        
        
        return false;
    }
    
    public void createList(int num) {
        for (int N = 0; N < num; N++) {
            add(N+1);
        }
//        printBackwards();
//        print();
//        System.out.println("Check 2");
    }
    
    public void print(){
        Node iter = first;
        while(i != j)
        {
            System.out.println(iter.getData());
            iter = iter.getNext();
            j++;
        }
        j = 0;
    }
    
    public void printBackwards(){
        Node iter = last;
        while(i != j)
        {
            System.out.println(iter.getData());
            iter = iter.getPrev();
            j++;
        }
        j = 0;
    }
    
    public int stun(int num) {
        for (int k = 0; k < num; k++) {
            stun = stun.getPrev();
        }
//        System.out.println(stun.getData());
//        deleteNode(temp.getData());
        return stun.getData();
    }
    
    public void stunNext() {
        stun = stun.getPrev();
    }
    
    public int cow(int num) {
//        System.out.println("Check 5");
        for (int m = 0; m < num; m++) {
            cow = cow.getNext();
        }
//        System.out.println(cow.getData());
//        deleteNode(temp.getData());
        return cow.getData();
    }
    
    public void cowNext() {
        cow = cow.getNext();
    }
    
    public void decide(int cowInput, int stunInput) {
        
//        System.out.println(cowInput);
//        
        cowNum = cowInput;
        stunNum = stunInput;
        
//        System.out.println(cowNum);
//        System.out.println(stunNum);
        
//        System.out.println(cow.getNext().getData());
//        System.out.println(cow.getPrev().getData());

        
        if (cowInput == stunInput) {
            fout.writer(cow.getData());
            int k = cowInput;
            cowNext();
            stunNext();
            deleteNode(k);
        } else if (cow == null || stun == null) {
            fout.writer("");
            fout.writer("End of Program " + y);
            System.exit(0);
        } else if (cowInput != stunInput) {
            fout.write(stun.getData() + " ");
            fout.write(cow.getData() + "\n");
            int s = stun.getData();
            int c = cow.getData();
            if (cow.getNext().getData() == stun.getData()) {
                cowNext();
            } else if (stun.getPrev().getData() == cow.getData()) {
                stunNext();
            }
            stunNext();
            cowNext();
            deleteNode(s);
//            System.out.println("deleted s");
            deleteNode(c);
//            System.out.println("deleted c");
        }
    }
    
    public void game(int[] par) {
        
        y++;
        
        fout.writer("Program " + y);
        fout.writer("---------");
        fout.writer("");
        fout.write("N = ");
        fout.write(par[0]);
        fout.write(", k = ");
        fout.write(par[1]);
        fout.write(", m = ");
        fout.write(par[2]);
        fout.writer("");
        fout.writer("");
        fout.writer("Output");
        fout.writer("------");
        fout.writer("");

        
        createList(par[0]);
        
        int cowPar = par[2];
        int stunPar = par[1];
        
//        System.out.println(par[2]);
//        System.out.println(par[1]);
        
        do {
//            printBackwards();
            decide(cow(cowPar), stun(stunPar));
//            printBackwards();
            z++;
//            System.out.println(z);
        } while (z < 3);
//        printBackwards();
    }
}
