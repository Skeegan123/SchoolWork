
typedef struct {
    char number[100];
    char title[100];
} Class;
